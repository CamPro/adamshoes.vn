<?php
/**
* @模板   Dossy
* @版本   1.1.0
* @作者   david http://www.shopiy.com/
* @版权   Copyright (C) 2009 - 2012 Shopiy
* @许可   Shopiy许可协议 (http://www.shopiy.com/license)
*/

$_LANG['agreement'] = '我已看过并接受<a href="article.php?cat_id=-1" target="_blank">《用户协议》</a>';
$_LANG['last_month_order'] = '最近30天的订单';
$_LANG['affiliate_code'] = '推荐代码';
$_LANG['search_ship'] = '搜索配送方式';
$_LANG['back_home'] = '<a href="index.php" class="button"><span>返回首页</span></a>';
$_LANG['goto_user_center'] = '<a href="user.php" class="button"><span>用户中心</span></a>';
$_LANG['shopping_money'] = '购物金额小计<em class="price">%s</em>';


$_LANG['your_auction'] = '您竟拍到了<strong>%s</strong> ，现在去 <a href="auction.php?act=view&amp;id=%s" class="button"><span">购买</span></a>';
$_LANG['your_snatch'] = '您夺宝奇兵竟拍到了<strong>%s</strong> ，现在去 <a href="snatch.php?act=main&amp;id=%s" class="button"><span>购买</span></a>';
$_LANG['your_discount'] = '根据优惠活动<a href="activity.php">%s</a>，您可以享受折扣 %s';
